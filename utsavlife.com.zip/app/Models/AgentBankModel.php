<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AgentBankModel extends Model
{
    use HasFactory;
      protected $table = 'agent_bank';
    protected $guarded = [];
}
