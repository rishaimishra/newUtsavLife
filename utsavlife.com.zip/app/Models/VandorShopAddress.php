<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VandorShopAddress extends Model
{
    use HasFactory;

     protected $table = 'vandor_shop_address';
    protected $guarded = [];
}
