
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
    <meta name="author" content="Coderthemes">
    <link rel="shortcut icon" href="{{url('/')}}/public/vandorAgentJsCss/assets/images/favicon_1.png">
    <title>Figma</title>
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/core.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/components.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/pages.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/menu.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/icofont/icofont.min.css" rel="stylesheet" type="text/css">
    <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/responsive.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@100;200;300;400;500;600;700;800&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet"> 
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    {{-- <link href="{{url('/')}}/public/vandorAgentJsCss/assets/css/font-awesome.min.css" rel="stylesheet" type="text/css"> --}}