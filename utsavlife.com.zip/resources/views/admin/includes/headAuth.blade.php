
    <link rel="icon" href="{{url('/')}}/public/adminasset/assets/img/icon.png" type="image/gif" sizes="16x16">
    <link rel="icon" href="{{url('/')}}/public/adminasset/assets/img/icon.png" type="image/gif" sizes="18x18">
    <link rel="icon" href="{{url('/')}}/public/adminasset/assets/img/icon.png" type="image/gif" sizes="20x20">

    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/icofont.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/animate.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/normalize.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/all.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/style.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/responsive.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/shop.responsive.css">

    <!-- index-3 css -->
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/index-4.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/shop.css">