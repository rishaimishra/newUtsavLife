<style>
  .modal-body {
    max-height: 550px;
    overflow-y: auto;
    text-align: justify;
}
</style>
<!-- refund Modal -->
<div class="modal fade" id="refund" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="new-heading mb-0">Refund Policy</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h4 class="modal-heading">Refund And Cancellation Policy</h4>  
        <p class="modal-para">Please read the Booking terms and conditions carefully before purchasing/Booking to any of the services, as once you have purchased/Booked you cannot change, cancel your Order. Once you Booked and make the required payment, it shall be final and there cannot be any changes or modifications to the same and neither will there be any refund.</p>
      </div>
    </div>
  </div>
</div>