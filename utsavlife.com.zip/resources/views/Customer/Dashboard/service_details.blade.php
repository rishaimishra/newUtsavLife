@extends('Customer.layouts.app')
@section('title')
<title>Utsavlife | SD</title>
@endsection
{{-- @section('head') --}}
@include('Customer.includes.new_head')
@include('Customer.includes.new_header')
{{-- @endsection --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.css" integrity="sha512-YdYyWQf8AS4WSB0WWdc3FbQ3Ypdm0QCWD2k4hgfqbQbRCJBEgX0iAegkl2S1Evma5ImaVXLBeUkIlP6hQ1eYKQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    .cartbutton{
        padding: 4px 8px;
    outline: none;
    border: 1px solid rgb(3, 100, 165);
    color: rgb(89, 187, 252);
    border-radius: 5px;
    text-decoration: none !important;
  }
    .cartbutton:hover{
      background: rgb(3, 100, 165);
    }
  .cartbutton i {
    margin-right: 10px !important;
  }
</style>




{{-- -- start show single data -- --}}
<section class="products-details my-4">
   <div class="container">
      <div class="row">
         <div class="col-md-6 col-12 my-3">
            <img class="products-details-img" src="{{url('/')}}/storage/app/public/service/{{@$service->image}}" alt="">
         </div>
         <div class="col-md-6 col-12 my-3">
            <div class="products-details-content">
               <h1 class="new-heading mb-2">{{@$service->service}}</h1>
               <input id="pro-desc-{{@$service->id}}" type="hidden" value="{{@$service->description}}">
               <p class="font-lg text-heading m-0" style="font-size: 15px;"
               id="pro-text-{{@$service->id}}" 
               >{{substr(@$service->description,0, 50)}}</p>
               <span class="pro-desc-show-more" data-pro-desc-id="{{@$service->id}}" style="background: rgb(89, 187, 252);outline: none;border: none;border-radius: 4px;font-size: 12px;padding: 4px 8px; cursor: pointer;">show more</span>
               <hr>
               <div class="product-price">
                  <span class="new-price">₹ {{@$service->discount_price}}</span>
                  <span class="old-price">MRP <p>₹ {{@$service->price}}</p></span>
                  <span class="qty-price">({{@$service->price_basis}})</span>
               </div>
               <p class="font-lg taxes">inclusive of all taxes</p>
                @if(!@Auth::user()->id)
                                    <div class="add-cart">
                                    <a class="add cartbutton" href="#" data-bs-toggle="modal" data-bs-target="#myModalviewNew2{{$service->id}}"><i class="fas fa-shopping-cart mr-5"></i>Add
                                    </a>
                                 </div>
                                  @elseif(!@Auth::user()->role_id==3 || !@Auth::user()->role_id==4)
                                  @elseif(@Auth::user()->role_id==2)
                                 <div class="add-cart">
                                    <a class="add cartbutton" href="#" data-bs-toggle="modal" data-bs-target="#myModalviewNew2{{$service->id}}"><i class="fas fa-shopping-cart mr-5"></i>Add
                                    </a>
                                 </div>
                                 @endif
            </div>
         </div>
      </div>
   </div>
</section>
{{-- -- end show single data -- --}}
{{-- rohit modal --}}
<div class="modal" id="myModalviewNew2{{$service->id}}">
   <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
         <!-- Modal Header -->
         <div class="modal-header">
            <h4 class="new-heading mb-0">Proceed To Cart</h4>
         </div>
         <!-- Modal body -->
         <form action="{{ route('cust.add_to_cart.new') }}" method="POST" id="frm">
            @csrf
            <div class="modal-body">
               <h3 class="cart-heading">Service name: <b>{{$service->service}}</b></h3>
               <!-- <div class="col-md-6"> -->
               <input type="hidden" name="service_id" value="{{$service->id}}">
               @php
               $cat=DB::table('service__cruds')->where('service_id',$service->id)->pluck('category_id')->toArray();
               // print_r($cat);
               $allCat=DB::table('category__cruds')->whereIn('id',$cat)->get();
               @endphp
               <div class="modal-design">
                  <label for="#cart_category">Choose Occation</label>
                  <select name="cart_category" id="cart_category">
                     <option value="">Select</option>
                     @foreach(@$allCat as $val)
                     <option value="{{$val->id}}">{{@$val->category_name}}</option>
                     @endforeach
                  </select>
               </div>
               <div class="modal-design">
                  <label for="#date">Order Start Date</label>
                  <input type="date" name="date" id="date">
               </div>


                <div class="modal-design">
                  <label for="#date">Order End Date</label>
                  <input type="date" name="end_date" id="end_date">
               </div>

               <div class="modal-design" style="display:none;">
                  <label for="#cart_category">Time</label>
                  <select name="time">
                    
                     <option value="F">Full</option>
                     <option value="M">Morning</option>
                     <option value="N">Night</option>
                  </select>
               </div>
               <div class="modal-design">
                  <label for=""> Add Quantity</label>
                  <input type="number" class="quentity" name="quantity" id="quantityModal{{$service->id}}" value="1" min="1" {{-- onchange="changeQuantity2({{$service->id}})" --}}>
               </div>
               <div class="modal-design">
                  <label for="">Days</label>
                  <input type="number" readonly class="quentity" name="days" id="days" value="1" min="1">
               </div>
               <!-- </div> -->
            </div>
            <div class="modal-footer add-cart">
               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" name="btn" value="add" class="btn" style="background-color: #C61048; color:#fff"><i class="fas fa-shopping-cart mr-5"> </i> Add</button>
             <button type="submit" name="btn" value="book" class="btn" style="background-color: #C61048; color:#fff"><i class="fas fa-shopping-cart mr-5"> </i> Book Now</button>
            </div>
         </form>
      </div>
   </div>
</div>
{{-- end rohit modal --}}






@include('Customer.includes.new_footer')
@include('Customer.includes.new_script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
    var minDt=new Date().toISOString().split("T")[0];
    $("#date" ).attr("min", minDt);
    $("#end_date" ).attr("min", minDt);
$('#frm').validate({
rules:{
cart_category:{
required:true,
},
date:{
required:true,
},
end_date:{
required:true,
},
time:{
required:true,
},
},
messages:{
},
submitHandler: function(form){
   // alert(1)
   var startDate=$("#date").val();
   var endDate=$("#end_date").val();
   // console.log(startDate,endDate);

   if ((Date.parse(endDate) < Date.parse(startDate))) {
      alert("End date should be greater than Start date");
      // document.getElementById("ed_endtimedate").value = "";
      return false
    }
   else{
      //calculate day diff between 2 dates and put it in day field
      let date_1 = new Date(startDate);
      let date_2 = new Date(endDate);
      let difference = date_2.getTime() - date_1.getTime();
      // console.log(difference);
      let TotalDays = Math.ceil(difference / (1000 * 3600 * 24));
      // console.log(TotalDays );
      if(TotalDays==0){
         $("#days").val(1);
      }else{
         $("#days").val(TotalDays+1);
      }

      

      form.submit();
   }
},
});
});


$(document).ready(function () {
   $('body').on('click', '.pro-desc-show-more', function () {
      const id = $(this).attr('data-pro-desc-id')
      const t = $(`#pro-desc-${id}`).val().trim();

      $(`#pro-text-${id}`).text(t);
      $(this).remove();
   })
});

</script>