
{{-- new template head --}}
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    {{-- <title>Azency - Creative Marketing Agency & eCommerce HTML Template</title> --}}
    <meta name="keywords" content="marketing, digital, shop, ecommerce" />
    <meta name="description" content="Creative Marketing Agency & eCommerce HTML Template">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/style.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/responsive.css">
    {{-- <link rel="icon" href="{{url('/')}}/public/adminasset/assets/img/icon.png" type="image/gif" sizes="16x16">
    <link rel="icon" href="{{url('/')}}/public/adminasset/assets/img/icon.png" type="image/gif" sizes="18x18">
    <link rel="icon" href="{{url('/')}}/public/adminasset/assets/img/icon.png" type="image/gif" sizes="20x20"> --}}
    <link rel="icon" type="image/x-icon" href="{{url('/')}}/public/newDesignAsset/cart/dist/images/fav_icon.png">

    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/icofont.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/animate.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/normalize.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/all.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/style.css?v={{time()}}">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/responsive.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/shop.responsive.css">

    <!-- index-3 css -->
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/index-4.css?v={{time()}}">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/shop.css?v={{time()}}">

</head>

