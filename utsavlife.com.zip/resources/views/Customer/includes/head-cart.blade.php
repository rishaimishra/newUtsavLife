<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="icon" type="image/x-icon" href="{{url('/')}}/public/newDesignAsset/cart/dist/images/FAVICON.png">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/owl.carousel.min.css">
    <!-- font awaume -->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/all.min.css">
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/style.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/cart/dist/css/responsive.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/icofont.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/animate.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/normalize.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/all.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/style.css?v={{time()}}">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/responsive.css">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/index-4.css?v={{time()}}">
    <link rel="stylesheet" href="{{url('/')}}/public/adminasset/assets/css/shop.css?v={{time()}}">
	<title>Utsavlife - India's largest event organising company</title>

</head>
