

{{-- <script src="https://kit.fontawesome.com/446e463225.js" crossorigin="anonymous"></script>
<script src="{{url('/')}}/public/adminasset/assets/js/modernizr.min.js"></script>


    <script>
    var resizefunc = [];
    </script>
   
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/detect.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/fastclick.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.slimscroll.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.blockUI.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/waves.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/wow.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.nicescroll.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.scrollTo.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.app.js"></script>
   
    <script src="{{url('/')}}/public/adminasset/assets/plugins/moment/moment.js"></script>
   
    <script src="{{url('/')}}/public/adminasset/assets/plugins/waypoints/lib/jquery.waypoints.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/counterup/jquery.counterup.min.js"></script>
   
    <script src="{{url('/')}}/public/adminasset/assets/plugins/sweetalert/dist/sweetalert.min.js"></script>
    <!-- flot Chart -->
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.time.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.tooltip.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.resize.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.pie.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.selection.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.stack.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/plugins/flot-chart/jquery.flot.crosshair.js"></script>
   
    <script src="{{url('/')}}/public/adminasset/assets/pages/jquery.todo.js"></script>
   
    <script src="{{url('/')}}/public/adminasset/assets/pages/jquery.chat.js"></script> --}}
   
    {{-- <script src="{{url('/')}}/public/adminasset/assets/pages/jquery.dashboard.js"></script> --}}
{{--     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
       <script>
  $( function() {
    $( "#datepicker" ).datepicker({
	   onSelect: function(selected) {
          $("#datepicker2").datepicker("option","minDate", selected)
        }
    });
  } );
  </script>
   <script>
  $( function() {
    $( "#datepicker2" ).datepicker({
	   onSelect: function(selected) {
          $("#datepicker").datepicker("option","maxDate", selected)
        }
    });
  } );
</script>
    <script type="text/javascript">
    /* ==============================================

                Counter Up

                =============================================== */
    jQuery(document).ready(function($) {
        $('.counter').counterUp({
            delay: 100,
            time: 1200
        });
    });

    const myModal = document.getElementById('myModal')
const myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', () => {
  myInput.focus()
})
    </script> --}}





  <script src="{{url('/')}}/public/adminasset/assets/js/modernizr.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery-3.6.0.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/popper.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/owl.carousel.min.js"></script>

    <script src="{{url('/')}}/public/adminasset/assets/js/slick.js"></script>

    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.waypoints.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.counterup.min.js"></script>
    
    <script src="{{url('/')}}/public/adminasset/assets/js/countdown.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/typeit.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/isotope.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ "></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/vticker.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.lineProgressbar.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/ajax-form.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/mobile-menu.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/shop.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.elevatezoom.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery-ui.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/script.js"></script>


{{-- modal scripts cdn --}}

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>