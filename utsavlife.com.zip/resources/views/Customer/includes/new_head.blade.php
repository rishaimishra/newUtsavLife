<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="icon" type="image/x-icon" href="{{url('/')}}/public/newDesignAsset/cart/dist/images/fav_icon.png">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/dist/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/dist/css/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/dist/css/owl.carousel.min.css">
    <!-- font awaume -->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/dist/css/all.min.css">
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/dist/css/style.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/newDesignAsset/dist/css/responsive.css">
	<title>Utsavlife - India's largest event organising company</title>

</head>
