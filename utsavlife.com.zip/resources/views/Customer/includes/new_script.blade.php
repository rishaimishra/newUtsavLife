<script type="text/javascript" src="{{url('/')}}/public/newDesignAsset/dist/js/jquery.min.js"></script>
 <script src="{{url('/')}}/public/newDesignAsset/dist/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script type="text/javascript"  src="{{url('/')}}/public/newDesignAsset/dist/js/owl.carousel.min.js"></script>
 <script type="text/javascript" src="{{url('/')}}/public/newDesignAsset/dist/js/main.js"></script>