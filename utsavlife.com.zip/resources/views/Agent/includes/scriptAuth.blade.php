


    <script src="{{url('/')}}/public/adminasset/assets/js/modernizr.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery-3.6.0.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/popper.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/owl.carousel.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.waypoints.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.counterup.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/countdown.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/typeit.min.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/isotope.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ "></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/vticker.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/jquery.lineProgressbar.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/ajax-form.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/mobile-menu.js"></script>
    <script src="{{url('/')}}/public/adminasset/assets/js/script.js"></script>


{{-- modal scripts cdn --}}

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>